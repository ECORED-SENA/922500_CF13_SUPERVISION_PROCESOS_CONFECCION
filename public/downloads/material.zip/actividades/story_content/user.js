function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6MRITqtT4od":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

